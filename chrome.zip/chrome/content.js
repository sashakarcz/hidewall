// content.js
console.log('Content script loaded');
